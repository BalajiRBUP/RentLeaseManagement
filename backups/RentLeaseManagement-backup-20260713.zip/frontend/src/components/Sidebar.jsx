import { NavLink } from "react-router-dom";

// Matches the target architecture agreed in planning: one app, one nav,
// covering Rent + Lease instead of two separate Power Apps.
const NAV_ITEMS = [
  { to: "/", label: "Dashboard", enabled: true },
  { to: "/agreements", label: "Agreements", enabled: true },
  { to: "/masters", label: "Masters", enabled: true },
  { to: "/lease", label: "Lease Schedule", enabled: true },
  { to: "/amendments", label: "Amendments", enabled: true },
  { to: "/posting", label: "SAP Posting", enabled: false },
  { to: "/reports", label: "Reports", enabled: false },
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">Rent &amp; Lease</div>
      <nav>
        {NAV_ITEMS.map((item) =>
          item.enabled ? (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) => "nav-item" + (isActive ? " active" : "")}
            >
              {item.label}
            </NavLink>
          ) : (
            <span key={item.to} className="nav-item disabled" title="Coming in a future sprint">
              {item.label}
            </span>
          )
        )}
      </nav>
    </aside>
  );
}
