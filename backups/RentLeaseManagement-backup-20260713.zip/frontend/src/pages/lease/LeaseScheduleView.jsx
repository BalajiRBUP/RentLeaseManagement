import { useEffect, useState } from "react";
import { listAgreements, generateLeaseSchedule, getLeaseSchedule } from "../../api/client";

function formatINR(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(value || 0);
}

export default function LeaseScheduleView() {
  const [agreements, setAgreements] = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [schedule, setSchedule] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    listAgreements().then(setAgreements).catch(() => setError("Could not load agreements."));
  }, []);

  async function loadExisting(agreementId) {
    setSelectedId(agreementId);
    setSchedule(null);
    setError(null);
    if (!agreementId) return;
    setLoading(true);
    try {
      const data = await getLeaseSchedule(agreementId);
      setSchedule(data.total_periods > 0 ? data : null);
    } catch {
      setSchedule(null);
    } finally {
      setLoading(false);
    }
  }

  async function handleGenerate() {
    if (!selectedId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await generateLeaseSchedule(selectedId);
      setSchedule(data);
    } catch (err) {
      const detail = err?.response?.data?.detail;
      setError(typeof detail === "string" ? detail : "Could not generate schedule. Check the agreement's dates/discount rate.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h1>Lease Schedule (IND AS 116)</h1>
      {error && <div className="error-banner">{error}</div>}

      <fieldset>
        <legend>Select Agreement</legend>
        <div className="form-grid">
          <label>
            Agreement
            <select value={selectedId} onChange={(e) => loadExisting(e.target.value)}>
              <option value="">Select an agreement</option>
              {agreements.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.urn} — {a.agreement_name || "Unnamed"}
                </option>
              ))}
            </select>
          </label>
        </div>

        {selectedId && (
          <>
          <button type="button" className="btn-primary" style={{ marginTop: 16 }} onClick={handleGenerate} disabled={loading}>
            {loading ? "Working…" : schedule ? "Regenerate Schedule" : "Generate Schedule"}
          </button>
          <small style={{ display: "block", marginTop: 8 }}>
            Regeneration keeps periods before the latest approved amendment&apos;s effective date.
          </small>
          </>
        )}
      </fieldset>

      {schedule && (
        <>
          <fieldset>
            <legend>Summary</legend>
            <div className="card-grid">
              <div className="card">
                <div className="card-label">Initial Lease Liability</div>
                <div className="card-value">{formatINR(schedule.initial_liability)}</div>
              </div>
              <div className="card">
                <div className="card-label">Initial ROU Asset</div>
                <div className="card-value">{formatINR(schedule.initial_rou)}</div>
              </div>
              <div className="card">
                <div className="card-label">Total Interest</div>
                <div className="card-value">{formatINR(schedule.total_interest)}</div>
              </div>
              <div className="card">
                <div className="card-label">Total Depreciation</div>
                <div className="card-value">{formatINR(schedule.total_depreciation)}</div>
              </div>
              <div className="card">
                <div className="card-label">Total Periods</div>
                <div className="card-value">{schedule.total_periods}</div>
              </div>
            </div>
          </fieldset>

          <fieldset>
            <legend>Monthly Schedule</legend>
            <div style={{ overflowX: "auto" }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Period</th>
                    <th>Opening Liability</th>
                    <th>Interest</th>
                    <th>Payment</th>
                    <th>Closing Liability</th>
                    <th>Opening ROU</th>
                    <th>Depreciation</th>
                    <th>Closing ROU</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {schedule.periods.map((p) => (
                    <tr key={p.id}>
                      <td>{p.period_number}</td>
                      <td>
                        {p.period_start} → {p.period_end}
                      </td>
                      <td>{formatINR(p.opening_liability)}</td>
                      <td>{formatINR(p.interest_expense)}</td>
                      <td>{formatINR(p.lease_payment)}</td>
                      <td>{formatINR(p.closing_liability)}</td>
                      <td>{formatINR(p.opening_rou)}</td>
                      <td>{formatINR(p.depreciation)}</td>
                      <td>{formatINR(p.closing_rou)}</td>
                      <td>
                        <span className={`status-badge status-${p.status.toLowerCase()}`}>{p.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </fieldset>
        </>
      )}
    </div>
  );
}
