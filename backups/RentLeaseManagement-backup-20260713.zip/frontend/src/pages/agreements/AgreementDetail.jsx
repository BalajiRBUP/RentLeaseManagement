import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getAgreement } from "../../api/client";

function formatINR(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(value || 0);
}

export default function AgreementDetail() {
  const { id } = useParams();
  const [agreement, setAgreement] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    getAgreement(id)
      .then(setAgreement)
      .catch(() => setError("Could not load this agreement."));
  }, [id]);

  if (error) return <div className="error-banner">{error}</div>;
  if (!agreement) return <div>Loading…</div>;

  return (
    <div>
      <div className="page-header">
        <h1>
          {agreement.urn} <span className={`status-badge status-${agreement.status.toLowerCase()}`}>{agreement.status}</span>
        </h1>
        <Link to="/agreements" className="btn-secondary">
          ← Back to list
        </Link>
      </div>

      <fieldset>
        <legend>Summary</legend>
        <div className="detail-grid">
          <div>
            <span className="detail-label">Name</span>
            <div>{agreement.agreement_name || "—"}</div>
          </div>
          <div>
            <span className="detail-label">Period</span>
            <div>
              {agreement.start_date} → {agreement.end_date}
            </div>
          </div>
          <div>
            <span className="detail-label">Total Rent</span>
            <div>{formatINR(agreement.total_rent)}</div>
          </div>
          <div>
            <span className="detail-label">GST % / TDS %</span>
            <div>
              {agreement.gst_percentage}% / {agreement.tds_percentage}%
            </div>
          </div>
          <div>
            <span className="detail-label">Escalation</span>
            <div>
              {agreement.escalation_percentage}% every {agreement.escalation_period} months
            </div>
          </div>
          <div>
            <span className="detail-label">Discount Rate (IND AS 116)</span>
            <div>{agreement.discount_rate}%</div>
          </div>
          <div>
            <span className="detail-label">Security Deposit</span>
            <div>{formatINR(agreement.security_deposit)}</div>
          </div>
          <div>
            <span className="detail-label">Created By</span>
            <div>{agreement.created_by}</div>
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend>Vendor Allocation Breakdown</legend>
        <table className="data-table">
          <thead>
            <tr>
              <th>Vendor</th>
              <th>Cost Center</th>
              <th>Profit Center</th>
              <th>Split %</th>
              <th>Rent</th>
              <th>GST</th>
              <th>TDS</th>
              <th>Net Payable</th>
            </tr>
          </thead>
          <tbody>
            {agreement.allocations.map((a) => (
              <tr key={a.id}>
                <td>{a.vendor.vendor_name}</td>
                <td>{a.cost_center.cost_center_text}</td>
                <td>{a.profit_center.profit_center_text}</td>
                <td>{a.split_percentage}%</td>
                <td>{formatINR(a.calculated_rent)}</td>
                <td>{formatINR(a.calculated_gst)}</td>
                <td>{formatINR(a.calculated_tds)}</td>
                <td>{formatINR(a.net_payable)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </fieldset>
    </div>
  );
}
