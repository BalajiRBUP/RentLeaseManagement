import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { listAgreements } from "../../api/client";

function formatINR(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value || 0);
}

export default function AgreementList() {
  const [agreements, setAgreements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    listAgreements()
      .then((data) => setAgreements(data))
      .catch(() => setError("Could not load agreements from the API."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="page-header">
        <h1>Agreements</h1>
        <Link to="/agreements/new" className="btn-primary">
          + New Agreement
        </Link>
      </div>

      {error && <div className="error-banner">{error}</div>}
      {loading && <div>Loading…</div>}

      {!loading && !error && (
        <table className="data-table">
          <thead>
            <tr>
              <th>URN</th>
              <th>Name</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Total Rent</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {agreements.length === 0 && (
              <tr>
                <td colSpan={6} className="empty-row">
                  No agreements yet. Click "New Agreement" to create the first one.
                </td>
              </tr>
            )}
            {agreements.map((a) => (
              <tr key={a.id}>
                <td>
                  <Link to={`/agreements/${a.id}`}>{a.urn}</Link>
                </td>
                <td>{a.agreement_name || "—"}</td>
                <td>{a.start_date}</td>
                <td>{a.end_date}</td>
                <td>{formatINR(a.total_rent)}</td>
                <td>
                  <span className={`status-badge status-${a.status.toLowerCase()}`}>{a.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
