import { useEffect, useState } from "react";
import { getDashboardSummary } from "../api/client";

function formatINR(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value || 0);
}

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    getDashboardSummary()
      .then(setSummary)
      .catch(() => setError("Could not reach the API. Is the backend running on the configured URL?"));
  }, []);

  if (error) return <div className="error-banner">{error}</div>;
  if (!summary) return <div>Loading dashboard…</div>;

  return (
    <div>
      <h1>Dashboard</h1>
      <div className="card-grid">
        <div className="card">
          <div className="card-label">Total Agreements</div>
          <div className="card-value">{summary.total_agreements}</div>
        </div>
        <div className="card">
          <div className="card-label">Total Rent (monthly)</div>
          <div className="card-value">{formatINR(summary.total_rent)}</div>
        </div>
        {Object.entries(summary.by_status).map(([status, count]) => (
          <div className="card" key={status}>
            <div className="card-label">{status}</div>
            <div className="card-value">{count}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
