"""
Placeholder models for the next build phases (Lease Engine, Amendment Engine,
Posting). Kept here, deliberately minimal, so the overall architecture and
table relationships are visible now. Flesh these out sprint by sprint the
same way Agreement was built - don't fill them in speculatively.
"""
import uuid
from datetime import datetime

from sqlalchemy import Column, String, Date, DateTime, Numeric, Integer, ForeignKey
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class LeaseSchedule(Base):
    """One row per period (usually monthly) of the IND AS 116 lease schedule
    generated for an agreement: ROU depreciation, interest, liability roll-forward."""
    __tablename__ = "lease_schedules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agreement_id = Column(UUID(as_uuid=True), ForeignKey("agreements.id"), nullable=False)

    period_number = Column(Integer, nullable=False)  # 1, 2, 3... in order, for display/sorting
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)

    opening_liability = Column(Numeric(15, 2))
    interest_expense = Column(Numeric(15, 2))
    lease_payment = Column(Numeric(15, 2))
    closing_liability = Column(Numeric(15, 2))

    opening_rou = Column(Numeric(15, 2))
    depreciation = Column(Numeric(15, 2))
    closing_rou = Column(Numeric(15, 2))

    status = Column(String(30), default="Draft")  # Draft, Approved, Posted
    created_on = Column(DateTime, default=datetime.utcnow)


class Amendment(Base):
    """Records a change event against an agreement: rent increase/reduction,
    end date change, discount rate change, escalation change, termination, etc."""
    __tablename__ = "amendments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agreement_id = Column(UUID(as_uuid=True), ForeignKey("agreements.id"), nullable=False)

    amendment_type = Column(String(50), nullable=False)
    # Rent Increase, Rent Reduction, End Date Change, Discounting Rate Change,
    # Escalation Percentage Change, Escalation Period Change, Partial Termination,
    # Full Termination

    effective_date = Column(Date, nullable=False)
    old_value = Column(String(255))
    new_value = Column(String(255))

    status = Column(String(30), default="Pending")  # Pending, Approved, Rejected, Posted
    requested_by = Column(String(100))
    approved_by = Column(String(100))
    approved_on = Column(DateTime, nullable=True)
    created_on = Column(DateTime, default=datetime.utcnow)


class Posting(Base):
    """SAP OData posting log for an agreement/lease schedule line."""
    __tablename__ = "postings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agreement_id = Column(UUID(as_uuid=True), ForeignKey("agreements.id"), nullable=False)
    lease_schedule_id = Column(UUID(as_uuid=True), ForeignKey("lease_schedules.id"), nullable=True)

    posting_type = Column(String(30))  # RENT, INTEREST, DEPRECIATION
    document_number = Column(String(50))  # SAP document number returned by OData
    amount = Column(Numeric(15, 2))
    status = Column(String(30), default="Pending")  # Pending, Posted, Failed
    error_message = Column(String(500))
    posted_on = Column(DateTime)
    created_on = Column(DateTime, default=datetime.utcnow)
