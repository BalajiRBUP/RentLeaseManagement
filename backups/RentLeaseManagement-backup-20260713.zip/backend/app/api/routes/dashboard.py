from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.agreement import Agreement, AgreementStatus

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("/summary")
def get_summary(db: Session = Depends(get_db)):
    total_agreements = db.query(func.count(Agreement.id)).scalar() or 0
    total_rent = db.query(func.coalesce(func.sum(Agreement.total_rent), 0)).scalar()

    by_status = {
        status.value: db.query(func.count(Agreement.id))
        .filter(Agreement.status == status)
        .scalar()
        or 0
        for status in AgreementStatus
    }

    return {
        "total_agreements": total_agreements,
        "total_rent": float(total_rent),
        "by_status": by_status,
    }
