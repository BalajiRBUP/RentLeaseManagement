import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.lease_schedule import LeaseScheduleSummary
from app.crud import lease_schedule as crud_lease_schedule

router = APIRouter(prefix="/api/lease-schedules", tags=["Lease Schedule"])


@router.post("/generate/{agreement_id}", response_model=LeaseScheduleSummary)
def generate_schedule(agreement_id: uuid.UUID, db: Session = Depends(get_db)):
    try:
        agreement = crud_lease_schedule.regenerate_schedule_for_latest_amendment(db, agreement_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not agreement:
        raise HTTPException(status_code=404, detail="Agreement not found")
    return _build_summary(db, agreement_id)


@router.get("/{agreement_id}", response_model=LeaseScheduleSummary)
def get_schedule(agreement_id: uuid.UUID, db: Session = Depends(get_db)):
    return _build_summary(db, agreement_id)


def _build_summary(db: Session, agreement_id: uuid.UUID) -> LeaseScheduleSummary:
    from app.models.agreement import Agreement

    agreement = db.query(Agreement).filter(Agreement.id == agreement_id).first()
    if not agreement:
        raise HTTPException(status_code=404, detail="Agreement not found")

    periods = crud_lease_schedule.list_schedule_for_agreement(db, agreement_id)

    return LeaseScheduleSummary(
        agreement_id=agreement.id,
        agreement_urn=agreement.urn,
        total_periods=len(periods),
        initial_liability=periods[0].opening_liability if periods else 0,
        initial_rou=periods[0].opening_rou if periods else 0,
        total_interest=sum((p.interest_expense for p in periods), start=0),
        total_depreciation=sum((p.depreciation for p in periods), start=0),
        periods=periods,
    )
